package com.example.demo.controller;

import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/items")
public class ItemController {

    private Map<Integer, String> items = new HashMap<>();

    @GetMapping
    public Map<Integer, String> getAllItems() {
        return items;
    }

    @PostMapping
    public String addItem(@RequestBody String item) {
        int id = items.size() + 1;
        items.put(id, item);
        return "Item added with ID: " + id;
    }

    @PutMapping("/{id}")
    public String updateItem(@PathVariable int id, @RequestBody String newItem) {
        if (items.containsKey(id)) {
            items.put(id, newItem);
            return "Item with ID " + id + " updated.";
        } else {
            return "Item not found.";
        }
    }

    @DeleteMapping("/{id}")
    public String deleteItem(@PathVariable int id) {
        if (items.containsKey(id)) {
            items.remove(id);
            return "Item with ID " + id + " deleted.";
        } else {
            return "Item not found.";
        }
    }
}
