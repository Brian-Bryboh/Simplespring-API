# Simple Spring Boot REST API

A minimal Spring Boot project demonstrating basic CRUD operations using:

- `@GetMapping`
- `@PostMapping`
- `@PutMapping`
- `@DeleteMapping`

## How to Run

1. Add Spring Web dependency in your `pom.xml`.
2. Place `ItemController.java` in the correct package.
3. Run the Spring Boot application.
4. Test the endpoints using Postman or curl.

## Endpoints

- `GET /items`
- `POST /items` (plain text body)
- `PUT /items/{id}` (plain text body)
- `DELETE /items/{id}`
